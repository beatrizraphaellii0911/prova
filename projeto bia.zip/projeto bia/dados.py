# dados.py

equipamentos = []
salas = []
